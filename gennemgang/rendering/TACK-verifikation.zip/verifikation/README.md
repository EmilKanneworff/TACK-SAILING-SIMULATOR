# TACK · Verifikationspakke

Åbn [rapporten](rapport.md) for resultater og begrænsninger. [Kørselskommandoerne](kommandoer.md) beskriver de lokale prøver.

- [Rådata og måleoversigt](data/resume.json)
- [Sejlads i bevægelse](billeder/sejlads.mp4)
- [Historisk rapport og billedpar](kilde/efter/gennemgang/rendering/optimering.md)
- [Buildidentiteter](revisioner.json)
- `build/` indeholder de byggede artefakter med samme filstruktur som på lokalserveren.
- `kilde/` indeholder kildetræer, scripts og test. `aendringer/` indeholder de relevante patches.
- `SHA256SUMS` viser filhashes for den udpakkede pakke.
