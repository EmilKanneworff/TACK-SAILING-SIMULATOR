# TACK · Afsluttende verifikation

**Slutbuild `9e3326f286c9` kører på [localhost:4220](http://localhost:4220/).** Det bygger på Git-revision `8cb343fdef596dc14d05802798c5f0578ae78004` med én lokal runtimeændring til foilbådenes snapshots. Den historiske optimering `37be7ac83c33` og den oprindelige baseline `97841c6fe0a3` følger med. [Buildidentiteter](revisioner.json) · [Genkørsel](kommandoer.md)

| Sammenlignelig prøve | Før | Slut |
|---|---:|---:|
| AC72 · FPS, 61 s på Lav med 4× CPU-drosling | 28,8 | **44,6** |
| AC72 · Billedinterval p95, ms | 50,0 | **33,4** |
| AC72 · CPU pr. fysiktrin, ms | 11,15 | **9,65** |
| Lokal tospillerlobby · snapshot pr. klient, kB/s som JSON | 534–537 | **422–426** |

De 7.200 fysiktrin matchede eksakt mellem de adskilte kildetræer. Prøven omfattede alle fem både i 15 forløb med bl.a. kæntring, stagvending, grundkontakt, foilløft og touchdown. 65 Node-tests, 54 browserprøver og typekontrollen bestod. [Fuld paritetslog](data/fysikparitet.json)

Auto reducerede kosmetiske detaljer ved målt CPU-pres og opløsningen ved GPU-pres. Begge blev genoprettet gradvist efter belastningen. De gentagne shaderprøver viste lavere median i havnen og ingen konsistent GPU-forringelse i regn. Den sammenhængende sejlads varede 5 min. 25 sek. og omfattede kystpassage, alle fem bådtyper og syv bådskift. Alle syv afgående modeller blev frigivet. [Målenoter med før/efter-prøver](maalenoter.md) · [Sejlads i bevægelse](billeder/sejlads.mp4)

Snapshots havde inkluderet ca. 7,4 kB flygtige rorberegninger fra foilkatamaranen pr. pakke. De er fjernet fra kraftoversigten. Begge klienter holdt realtid i den lokale tospillerlobby. Seks reelt tilsluttede klienter delte samme Mac og nåede 0,81–0,85 simuleret sekund pr. realtidssekund. Serveren havde udsendelseskø under belastning. Seks spillere er dermed prøvet lokalt, og realtidskapaciteten er fortsat et udestående. [Multiplayer-rådata og codec-målinger](maalenoter.md#multiplayer)

En fysisk svagere telefon eller computer og en multiplayerprøve over internettet er udestående. Spillerens tidligere styringsproblem tæt på vindøjet var uden for denne ydelsesverifikation.
