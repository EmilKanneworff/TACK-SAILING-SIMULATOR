# Genskab målingerne

Pak ZIP-filen ud. Kildetræerne indeholder runtime og buildværktøjer. Færdige builds følger med. Chrome eller Playwright Chromium skal have WebGL2, og GPU-prøverne kræver GPU-timerudvidelsen. Pakkeinstallationen bruger npm. Kør derefter målingerne lokalt én browserprøve ad gangen.

Kør fra pakkens rod.

```sh
tack_pkg="$PWD"
cd "$tack_pkg/kilde/efter"
npm ci
npx playwright install chromium
# Sæt CHROME_PATH, hvis browseren ligger et andet sted end scriptets standardsti.
out="$tack_pkg/ny-maaling"
mkdir -p "$out/foer" "$out/efter" "$out/forrige"
tar -xzf "$tack_pkg/build/baseline.tar.gz" -C "$out/foer"
tar -xzf "$tack_pkg/build/slut.tar.gz" -C "$out/efter"
tar -xzf "$tack_pkg/build/foer-netvaerksrettelsen.tar.gz" -C "$out/forrige"
```

Start serverne i separate terminaler fra `kilde/efter`. Brug samme værdi for `out` i hver terminal. Hvis du genbygger, skal du bygge uden `VITE_REALTIME_URL` for at få de samme frontend-buildnumre.

```sh
FRONTEND_DIR="$out/foer" FRONTEND_PORT=4207 node server/static.js
FRONTEND_DIR="$out/efter" FRONTEND_PORT=4220 node server/static.js
FRONTEND_DIR="$out/forrige" FRONTEND_PORT=5173 node server/static.js
TACK_BUILD_DIR="$out/genbygget-slut" npm run build
(cd "$tack_pkg/kilde/foer" && TACK_BUILD_DIR="$out/genbygget-foer" node server/build.js)
curl -sI http://localhost:4220/
```

```sh
export TACK_AUDIT_STAGES=katamaran TACK_AUDIT_MS=61000 TACK_AUDIT_REPLAY=1 TACK_AUDIT_RAW=1 TACK_AUDIT_LAYERS=0 TACK_AUDIT_LIGHT=1
node scripts/render-audit.cjs http://localhost:4207/ "$out/baseline-light.json" low 4 mobile
TACK_AUDIT_INPUT=1 node scripts/render-audit.cjs http://localhost:4220/ "$out/final-light.json" low 4 mobile
TACK_AUDIT_INPUT=1 node scripts/render-audit.cjs http://localhost:4220/ "$out/final-auto.json" auto 4 mobile
node scripts/verify-water-gpu.cjs http://localhost:4220/ "$out/foer/index.html" "$out/water-ab.json"
node scripts/verify-auto-pressure-offscreen.cjs http://localhost:4220/ "$out/auto-pressure.json"
TACK_GPU_ONLY=1 node scripts/verify-auto-pressure.cjs http://localhost:4220/ "$out/auto-gpu-overlay.json"
node scripts/verify-sailing-input.cjs http://localhost:4220/ "$out/input-final.json"
node scripts/verify-sailing-experience.cjs http://localhost:4220/ "$out/experience"
```

```sh
cd "$out/experience/frames"
ffmpeg -safe 0 -f concat -i concat.txt -vf 'pad=ceil(iw/2)*2:ceil(ih/2)*2' -r 30 -c:v libx264 -pix_fmt yuv420p ../sejlads.mp4
cd "$tack_pkg/kilde/efter"
```

Start to lokale instanser af den eksisterende live-tjeneste. Kør begge målinger af browserautoritet mod samme server. Hver browserkontekst forbinder som sin egen lobbyklient.

```sh
TACK_LIVE_AUTHORITY=browser PORT=4324 TACK_LIVE_SERVER_PROFILE="$out/server-two.json" TACK_BUILD=9e3326f286c9 node -r ./scripts/profile-live-server.cjs server/index.js
TACK_LIVE_AUTHORITY=server PORT=4325 TACK_LIVE_SERVER_PROFILE="$out/server-six.json" TACK_BUILD=9e3326f286c9 node -r ./scripts/profile-live-server.cjs server/index.js
```

```sh
TACK_LIVE_CLIENTS=2 TACK_LIVE_URL=ws://127.0.0.1:4324 node scripts/profile-live-render.cjs http://localhost:5173/ "$out/live-before.json"
TACK_LIVE_CLIENTS=2 TACK_LIVE_URL=ws://127.0.0.1:4324 node scripts/profile-live-render.cjs http://localhost:4220/ "$out/live-two.json"
TACK_LIVE_CLIENTS=6 TACK_LIVE_URL=ws://127.0.0.1:4325 node scripts/profile-live-render.cjs http://localhost:4220/ "$out/live-six.json"
```

```sh
unset TACK_AUDIT_STAGES TACK_AUDIT_MS TACK_AUDIT_REPLAY TACK_AUDIT_RAW TACK_AUDIT_LAYERS TACK_AUDIT_LIGHT
TACK_AUDIT_STAGES=solo-flaadescene,to,seks TACK_AUDIT_MS=4100 TACK_AUDIT_RAW=1 TACK_AUDIT_LAYERS=0 node scripts/render-audit.cjs http://localhost:4220/ "$out/fleet-final.json" high
TACK_AUDIT_RACE=1 TACK_AUDIT_MS=9000 TACK_AUDIT_RAW=1 TACK_AUDIT_LAYERS=0 TACK_AUDIT_IMAGES="$out/experience" node scripts/render-audit.cjs http://localhost:4220/ "$out/race-final.json" low
node scripts/verify-render-physics.cjs "$out/foer/assets" "$out/fysikparitet.json"
node scripts/summarize-render-verification.cjs "$out" > "$out/resume.json"
npm test
npm run check:simulation
npx playwright test tests/render-quality.test.js tests/water-effects.test.js tests/wave-crew-experience.test.js tests/reconnect.test.js tests/difficulty.test.js --workers=1 --reporter=line
```

`data/resume.json` samler percentilerne. Den historiske rapport i `kilde/efter/gennemgang/rendering/optimering.md` har de tidligere målinger og kommandovarianter. `build/rapport.tar.gz` er buildet, rapporten målte.
