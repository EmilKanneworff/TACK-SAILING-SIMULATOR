# TACK · Afsluttende verifikation

Slutbuild **`9e3326f286c9`** er tilgængeligt på [localhost:4220](http://localhost:4220/). Browserens revisionsmærke og serverens svarheader stemmer overens. Den gentagne prøve med foilkatamaranen gik fra **28,8 til 44,6 FPS** ved samme opløsning og 4× CPU-drosling. CPU pr. fysiktrin faldt fra **11,15 til 9,65 ms**.

- Førversion **`97841c6fe0a3`** fra `412cd1d76a9b201651b5470606bf131c89436638`.
- Rapportens mellemversion **`37be7ac83c33`** fra samme Git-base med datidens lokale optimeringer. Artefaktet og den genskabte runtime-patch følger med. Patchen genbyggede til samme build-ID. De tidligere billedpar og den gamle rapport ligger under [optimering](kilde/efter/gennemgang/rendering/optimering.md).
- Slutversion **`9e3326f286c9`** fra `8cb343fdef596dc14d05802798c5f0578ae78004` med den lokale ændring til foil-snapshots. Den samme Git-revision uden ændringen giver **`7d550f20c7a8`** og bruges som førversion til den aktuelle lobbyprøve. [Identiteter og filhashes](revisioner.json) · [Kørselskommandoer](kommandoer.md)

## Foilkatamaran og Auto i 61 sekunder

Apple M5, model Mac17,2, 32 GiB, macOS 26.3. Chrome 158.0.8127.37 headless, ANGLE Metal. Portræt med 390 × 664 CSS-pixel, DPR 3, touch-emulering og 4× CPU-drosling. Kamera Følg, AC72 i åbent vand, samme gemte starttilstand, vejr og tidsstyrede ror-, skøde- og vægtinput. De tre optagelsers starttilstand og input blev sammenlignet eksakt. Prøvevejret brugte 8 m/s fra 255°, 0,38 m bølger og 42 % chop. Alle rækker tegnede ved 288 × 491 på Lav. Auto begyndte det målte vindue på kosmetisk CPU-trin 1 og tegnede 2.712 af 2.750 billeder på trin 2. Slutbuildets manuelle Lav brugte 0.

| Build og interval | FPS | Billedinterval p50 / p95 / p99 / maks., ms | Over 100 ms | Gæld start / maks. / slut, ms | Simtid / realtid | CPU ms/trin |
|---|---:|---:|---:|---:|---:|---:|
| Før · 0–10 s | 23,6 | 33,4 / 66,7 / 66,7 / 66,8 | 0 | 717 / 717 / 66 | 1,068 | 11,21 |
| Før · 10–61 s | 29,9 | 33,3 / 50,0 / 50,1 / 66,7 | 0 | 66 / 98 / 81 | 0,999 | 11,13 |
| Slut, Lav · 0–10 s | 36,1 | 33,3 / 50,0 / 50,1 / 66,7 | 0 | 567 / 567 / 16 | 1,057 | 9,86 |
| Slut, Lav · 10–61 s | 46,3 | 16,7 / 33,4 / 33,4 / 33,5 | 0 | 16 / 48 / 14 | 1,000 | 9,61 |
| Slut, Auto · 0–10 s | 38,5 | 16,8 / 50,0 / 50,0 / 66,7 | 0 | 517 / 517 / 16 | 1,052 | 9,76 |
| Slut, Auto · 10–61 s | 46,4 | 16,7 / 33,4 / 33,4 / 50,0 | 0 | 16 / 65 / 14 | 1,000 | 9,60 |

De første 10 sekunder regnes fra starten af målevinduet efter den fælles klargøring. Det inkluderer indhentning af gæld fra klargøringen. Billedintervaller måles mellem faktisk tegnede billeder inden for hvert vindue. Simulationsregnskabet var inden for 10 ms for de to Lav-prøver og ét billedinterval for Auto. Den aktive solospilløkke bevarede tiden i gæld og kasserede **0 ms**. Total-FPS var 28,8, 44,6 og 45,1. [Før](data/baseline-light.json) · [Slut, Lav](data/final-light.json) · [Slut, Auto](data/final-auto.json) · [Beregninger](data/resume.json)

Ror og skøde blev indledningsvis målt med seks tastaturhændelser efter hver af de to slutprøver. Første ændring større end 0,003 rad på roret eller 0,003 af skøderangen blev aflæst ved næste browsercallback. På Lav måltes ror **45,7 / 19,7 / 18,4 ms** og skøde **20,0 / 18,2 / 16,9 ms**. Auto gav **48,3 / 31,8 / 27,2 ms** og **31,0 / 22,4 / 17,8 ms**. Dette er tid til observeret ændring af simulationstilstanden. Skærm- og touchforsinkelse kræver separat måling. En særskilt 61-sekunders prøve brugte ni almindelige tastetryk omkring 5, 24 og 49 s med `isTrusted=true`. Roret reagerede efter 17,9–35,0 ms og skødet efter 23,6–28,7 ms på Auto, CPU-trin 2. [Rådata for almindelige input](data/input-final.json)

## Auto under kontrolleret pres

Med fire gange CPU-drosling og AC72 på desktop faldt medianen til 30,5 FPS. Auto klassificerede flaskehalsen som fysik og gik fra kosmetisk trin 0 til 1 og 2 ved 1649 × 1030. Efter droslingen blev slået fra, var medianen 60 FPS. CPU-detaljerne kom tilbage ét trin ad gangen efter ca. 10 og 20 sekunder. [CPU-forløb](data/auto-pressure.json)

I GPU-prøven lagde måleværktøjet reelle shaderpassager over den almindelige desktopvisning. De begyndte ved let pres og blev øget, til GPU-tiden nåede ca. 22,7 ms, og det seneste FPS-vindue målte 41. Auto gik fra Balanceret 1317 × 823 til Lav 789 × 493. CPU-detaljer forblev på trin 0. På Lav faldt GPU-tiden til ca. 8–9 ms, og billedfrekvensen kom tilbage til ca. 60. Auto prøvede én opgradering efter ca. 10 sekunder, faldt tilbage under fortsat pres og ventede derefter ca. 25 sekunder før næste opgradering. Efter aflastning nåede det først Balanceret og derefter Høj. Belastningen blev tilført af testen. [GPU-forløb](data/auto-gpu-overlay.json)

## Vandshader

A/B-prøven byttede de to ændrede dele af vandets fragmentshader i slutbuildet. Scene, stilling, kamera, uniforms, vandnet og billedbuffer på 1649 × 1030 var fælles, og der indgik fire skiftevis placerede par. Hver blok blev kompileret, varmet med 18 billeder og derefter målt i 80 GPU-forespørgsler. Der manglede 0 af 1.280 resultater. Timeren måler hele hovedvisningen. Shaderen er den eneste tilsigtede forskel.

| Scene | Forskelle i parrenes median, ny minus original, ms | Konklusion |
|---|---:|---|
| Havn | −0,19 / −0,23 / −0,83 / −0,20 | Den nye variant målte lavere median i hvert par, med overlap i de langsomste billeder. |
| Katamaran i regn | +0,15 / −1,65 / +1,91 / +2,14 | Medianmålingerne varierede meget, også mellem blokke af samme shader. P95 var 5,96–6,09 ms med ny og 6,12–6,32 ms med original shader. Der er ingen konsistent, isoleret forringelse, der begrunder at ændre vandshaderen. |

[GPU-rådata, tid og kamera](data/water-ab.json) · [Sammenlignelige billeder](kilde/efter/gennemgang/rendering/optimering-data/billeder)

## Sejlads, kyst og bådskift

Den samme browser kørte **325,4 sekunder** gennem almindelig Fri sejlads med Let, Auto og spillets ror og skødeskyder. Forløbet startede ved læprøvens kyst, sejlede ca. **956 spilmeter** over de målte delstræk og kom mellem **6,5 og 134 spilmeter** fra nærmeste kystlinje. Afstanden er efterberegnet ved projektion på kystpolygonernes linjestykker. Bunddybden var 8,5–28,7 m langs de samplede punkter. Bådskiftene brugte bådmenuen. De målte delstræk dækker 318,4 simulerede sekunder. De korte mellemrum over bådskiftene er udeladt af summen. Ruten blev derfor opgjort pr. stræk ved skiftets nulstilling. CPU blev droslet 2× og senere 4× under den tætte serie af bådskift.

Alle fem både blev prøvet. Auto skiftede fra Balanceret til Høj under forløbet. Besætningens side skiftede i både fysisk og tegnet tilstand, og 9 vindpile var aktive ved alle loggede målepunkter. Loggen indeholder vandkontakt ved 8–18 prøvepunkter, aktivt kølvand og op til 24 registrerede sprøjtpartikler. Rorudslaget gik fra ca. −25,7° til +25,5°. Der var ingen browserfejl, kæntringer eller grundkontakter i denne prøve. Den gamle model blev frigivet ved alle **7 af 7** bådskift, med højst **1** planlagt frigivelse ad gangen og **0** tilbage ved slut. Det er en kontrol af oprydningskøen og antal objekter. VRAM i bytes blev ikke målt.

[Rå log](data/sejlads.json) · [Video](billeder/sejlads.mp4)

## Bevaret sejladsfysik i de afprøvede forløb

Paritetsprøven sammenligner **7.200 trin i alt**. Fem både × tre scenarier × 480 trin ved 60 Hz giver otte sekunder pr. scenarie. De to adskilte kildekataloger indlæses via hver sin modulfil. Scriptet kontrollerer, at filernes reelle stier og simulationsfunktionerne er forskellige, og sammenligner hele den tilgængelige, enumerable bådtilstand før og efter hvert trin med `deepStrictEqual`. Det omfatter position, orientering, alle hastigheder, sejl og ror, masse/CG/inerti, besætning, bølgeprofil, skrog- og appendagelaster, foilbenenes tilstand samt kræfter og momenter. Ingen pålagt uniform strøm. Vandets lokale bølgebevægelse indgår i modellen.

| Scenarie for hver båd | Startpunkt x / y, m | Startfart m/s | Vind og bølger |
|---|---:|---:|---|
| Åbent hav | −1775 / −1980 | 4 | 12 m/s fra 252°, 0,90 m, chop 65 % |
| Større sø og foilstart | −1480 / −1825 | 12 | 16 m/s fra 275°, 1,60 m, chop 65 %. Foilbåde starter ved heave 1,15 m. |
| Kyst | −180 / −340 | 3 | 12 m/s fra 025°, 0,34 m, chop 0 % |

Startretningen var −0,54 rad i simulatorkoordinater, skøde 52 %, Svær, vindseed 61 og bølgeseed 127. Efter 2 s kommer styrbordsror og indhal. Ved 3 s skiftes til bagbordsror, slæk og ny besætningsplacering, side og vægt agter. Efter 4 s drejer vinden 17°, og den valgte bølgehøjde bliver 70 % af den tidligere. Efter 4,5 s neutraliseres roret, skødet sættes til 54 %, og vægten flyttes frem. Rådata indeholder fuld starttilstand, faktiske hændelser og feltliste pr. scenarie. [Script](kilde/efter/scripts/verify-render-physics.cjs) · [Paritetsdata](data/fysikparitet.json)

`waterForInstant` i `physics.js` forbereder én bølgetilstand ved det aktuelle trin. Den genbruges kun inden for den faste tid og vejrmæssige tilstand. Position og prøvedybde gives til hver beregning. `foilWaterPasses` i `foils.js` genbruger vandværdier mellem de to kraftpassager, når x, y og dybde stemmer eksakt, og kasseres inden næste foil-deltrin. En flyttet arm kræver nye prøver. Første gennemløb kan desuden genbruge de fem neddykningspunkter på rorets hele vinge, hvor geometrien er identisk. Flapper, neddykning ved flyttede prøvepunkter, relativ strømning, kræfter, momenter og massebidrag beregnes ved den aktuelle pose og belastning. Prøven dækker både vejrændring og foilindstillinger. [Fysikkode](kilde/efter/assets/simulation/physics.js) · [Foilkode](kilde/efter/assets/simulation/foils.js)

De fire tilpassede opstillinger bevarer testenes adfærdskrav. To stillevandstests bruger eksplicit `waveHeight:0` og `chop:0`, fordi de tidligere `waves`/`sea`-defaults slap reel sø igennem. To tests af kystlæ bruger `ArchipelagoData.fromMetric` efter kortets komprimering. Den længere af de to ruter prøver stadig begge sider af læområdet og sammenligner pilens bevægelse med lokal vind midt i dens faktiske tids- og positionsinterval. [Vandtest](kilde/efter/tests/water-effects.test.js) · [Vindtest](kilde/efter/tests/wave-crew-experience.test.js) · [Patch](aendringer/412cd1d-til-8cb343f.patch)

Den mellemkommende ændring til 1–3 og Q/E på Svær blev lavet særskilt. Pariteten sammenligner motorens svar med identiske inddata. Den påstår derfor ingen lighed af tastetildelingen hen over den ændring. Spillerens tidligere rapport om jollen tæt på vindøjet, fuldt indhalet og næsten uden fart, er et styringsspørgsmål uden for denne ydelsesafslutning.

Den observerede stagvending med Laser skete nær kysten ved 2,73 s. Laser kæntrede i de to andre prøver ved henholdsvis 1,38 og 2,18 s. Racer, Turbåd og begge foilbåde fik grundkontakt i kystscenariet. AC75 og AC72 skiftede mellem vandbåren, løftende og foilende tilstand. AC75 havde også touchdown ved kysten. Ingen gybes blev registreret. Rådata viser start, input, sluttilstand og hændelser for hvert af de 15 forløb.

## Multiplayer

Det historiske tal omkring 530 kB/s talte UTF-8 bytes i de modtagne WebSocket-tekstrammer, efter browseren havde fjernet transportkomprimering, og før klientens JSON-afkodning. `permessage-deflate` var forhandlet i alle de nye målinger. Tabellens kB er 1.000 bytes af JSON. Komprimerede bytes på nettet, TCP-overhead og RTT blev ikke målt.

`packBoat` fjernede i forvejen folieelementernes beregningsdele under `foils`. `forces.rudder` henviste til den komplette kopi af rorresultatet og tog alligevel delene med. Et målt AC72-eksemplar før rettelsen brugte **7,38 kB** til `forces.rudder.parts` alene. Nu sender kraftoversigten den allerede reducerede rorstruktur. De målte 26,31 kB for AC72 blev 18,87 kB, mens Laser forblev omkring 10,8 kB. Foliernes øvrige tilstand fyldte ca. 5,5 kB. Efter patchen fyldte `forces` ca. 2,7 kB på AC72 og 2,9 kB på Laser. De løbende kraft- og styredata på konventionelle både bevares, herunder rordele, som næste trin bruger. Begge foilprofiler bestod en test, hvor næste komplette fysiktrin skulle være identisk efter gendannelse fra de to pakketyper. [Ændring](kilde/efter/assets/simulation/live-room.js) · [Regressionstest](kilde/efter/tests/server.test.js)

| Tjeneste og klient | Indgående snapshots kB/s | Snapshots/s | Typisk JSON pr. snapshot | FPS | Billedinterval p95 ms | Simtid / realtid |
|---|---:|---:|---:|---:|---:|---:|
| Browserautoritet før · vært og gæst | 534–537 | 14,2 | 37,68 kB | 60,0–60,1 | 17,5–20,4 | 0,996–1,003 |
| Browserautoritet efter · vært og gæst | 422–426 | 14,0–14,1 | 30,22 kB | 59,2–60,1 | 17,8–20,0 | 1,005 |
| Serverautoritet efter · seks klienter | 533–563 | 6,5–6,9 | ca. 82,2 kB | 36,9–37,7 | 37,0–86,3 | 0,807–0,845 |

Tallene for to klienter er sammenlignelige på samme lokale relay og grafikprofil. Det enkelte snapshot faldt ca. **20 %**. Værtens upload med `authority-frame` faldt **534 → 425 kB/s**. Spillerinput lå ved ca. 20–21/s og 7,0–7,5 kB/s pr. klient. Relayet sendte normalt omkring 40 `authority`-beskeder/s til værten ved to klienter, ca. 17 kB/s. Rådata indeholder frekvens og størrelse pr. beskedtype og klient.

Medianen for værtens pakning var under 0,1 ms. P95 var ca. 0,10 ms til pakning og 0,20 ms for det synkrone `postMessage`-kald. Den måling omfatter den observerbare afleveringsomkostning i workeren. Asynkron transport og deserialisering på den modtagende tråd er uden for det tidsinterval. Klienternes JSON-afkodning var ca. 0,1–0,2 ms p95 for to og 0,3–0,4 ms for seks. Browserens `JSON.stringify` lå ved højst ca. 0,1 ms p95. Relayets median for JSON-afkodning af værtspakken og kodning af snapshot gik fra ca. 0,17/0,17 ms til 0,11/0,10 ms. Klientens korrektion, inklusive kopi af autoritativ tilstand og genafspilning af ventende input, lå på ca. 2 ms p95 på værts-Laser og 9 ms på gæstens AC72 ved to. Den højeste p95 for seks var ca. 74 ms på AC72. Zlib, TCP og den asynkrone kopi har ingen særskilt CPU-måling her.

To klienter havde typisk 7–8 ventende input p95, med 15 som højeste observerede kortvarige udsving efter rettelsen. Værtens worker kasserede 0 ms. Seks klienter nåede 18 ventende input p95. Klienternes observerede udsendelsesbuffer var 0 bytes ved slut i seksspillerprøven. Serverens `bufferedAmount` nåede **329.403 bytes** lige efter afsendelser, over grænsen på 256 KiB for at begynde på et nyt snapshot. Serveren kan derfor springe et erstatteligt snapshot over, når køen er høj. Komplette seksspillertrin målte ca. 19 ms i median, hvilket overstiger 60 Hz-budgettet på 16,67 ms. Både autoritetstrin og afsendelseskø begrænsede forsøget. Forskellen fra seneste autoritative simulationstid var ca. 50 ms p95 med to og 200–217 ms p95 med seks. Det tal er klientens fremrykning i simulationen.

Alle seks var uafhængige Chrome-kontekster med rigtig lobbykode, hver sin WebSocket, almindelige ror- og skødeinput og fem modspillere i deres flådetilstand. Server og browsere delte samme Mac. Den lokale instans brugte samme Node-tjeneste som projektet med serverautoritet og seks pladser. Den gratis browserautoritative konfiguration har to pladser. Offentlig internettrafik, flere maskiner og en fysisk svagere telefon eller computer er udestående.

[To klienter før](data/live-before.json) · [To efter](data/live-two.json) · [Seks efter](data/live-six.json) · [Relay-profil](data/server-two.json) · [Serverprofil](data/server-six.json)

## Supplerende grafikprøver

På Høj i den korte flådescene var de 1, 2 og 6 både synlige med 1649 × 1030 og ca. 60 FPS i én browser. De tre optalte billeder havde henholdsvis 151, 248 og 887 tegnekald. Hovedtrådens billedarbejde p95 var 2,5, 3,4 og 7,6 ms. Prøven isolerer tegningen af flåden. Prøven med seks klienter indeholder også seks browseres eget arbejde og fælles serversimulation. Kapsejladsen blev åbnet gennem menuen på Lav. Der blev målt 23 separate tegnekald til banemarkeringer i den almindelige hovedvisning. [Flåderådata](data/fleet-final.json) · [Baneprøve](data/race-final.json) · [Billede af banen](billeder/kapsejlads.jpg)


## Afsluttende kontrol

65 Node-tests og typekontrollen bestod. 54 browserprøver bestod mod den aktuelle kilde, herunder styreinput, besætningsplacering, WebGL-gendannelse, grafikniveau og LOD, vindpile, vandkontakt, bådbevægelse og genforbindelse. Måleforløbene på den byggede frontend kontrollerede også serverheader og build-ID. De udpakkede kilder genbyggede til de registrerede ID'er. [Node-log](data/npm-test.txt) · [Typekontrol](data/typecheck.txt) · [Browserlog](data/browser-tests.txt)
