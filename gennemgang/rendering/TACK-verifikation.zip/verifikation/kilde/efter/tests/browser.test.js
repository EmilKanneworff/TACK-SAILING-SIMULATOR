'use strict';
const {test,expect}=require('@playwright/test');
const {dragMap,introOption}=require('../scripts/browser-setup.cjs');
const {pathToFileURL}=require('node:url');const path=require('node:path');
test.use({launchOptions:{executablePath:process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--enable-unsafe-swiftshader']}});

test('the boat picker opens all five sizes in one view with room to scroll on a phone',async({page})=>{
  await page.setViewportSize({width:1280,height:720});
  await page.goto(process.env.TACK_URL||pathToFileURL(path.resolve('index.html')).href);
  await page.click('#startButton');
  await page.click('#boatMenuButton');
  const opened=page.waitForEvent('popup');
  await page.getByRole('link',{name:'Sammenlign størrelser'}).click();
  const comparison=await opened;
  const viewport=comparison.locator('.comparison-viewport');
  const labels=comparison.locator('.comparison-labels li');
  await expect(comparison.locator('#boatComparison')).toHaveAttribute('data-ready','true');
  await expect(labels.locator('strong')).toHaveText(['Laserjolle','Racer 32','Turbåd 43','Foilmonohull','Foilkatamaran']);
  await expect(labels.locator('span')).toHaveText(['4,23 m','9,75 m','13,1 m','20,7 m','22 m']);
  await expect(labels.last()).toBeInViewport({ratio:.99});
  expect(await viewport.evaluate(element=>element.scrollWidth)).toBe(await viewport.evaluate(element=>element.clientWidth));
  expect(await comparison.evaluate(()=>typeof window.SAILING_GAME)).toBe('undefined');

  await comparison.setViewportSize({width:390,height:844});
  await expect(comparison.getByText('Rul sidelæns for at se alle fem både.')).toBeVisible();
  await labels.last().scrollIntoViewIfNeeded();
  await expect(labels.last()).toBeInViewport();
  expect(await viewport.evaluate(element=>element.scrollLeft)).toBeGreaterThan(0);
  await comparison.getByRole('link',{name:'Tilbage til spillet'}).click();
  await expect(comparison.locator('#startButton')).toBeEnabled();
  await expect(page.locator('#boatPicker')).toBeVisible();
});

test('free sailing starts with clear water ahead when the wind is straight into the normal route',async({page})=>{
  await page.clock.install();
  await page.goto(process.env.TACK_URL||pathToFileURL(path.resolve('index.html')).href);
  await (await introOption(page,'#introWeatherEdit')).click();
  await page.locator('#windSpeed').fill('10');
  await page.locator('#windDirection').fill('153');
  await page.keyboard.press('Escape');
  await page.click('#startButton');
  const windAngle=await page.evaluate(()=>Math.abs(SAILING_GAME.state.wind.twa)/SailPhysics.DEG);
  expect(windAngle).toBeGreaterThan(55);
  await page.keyboard.down('ArrowUp');
  await page.clock.runFor(540);
  await page.keyboard.up('ArrowUp');
  await page.clock.runFor(7500);
  const sailing=await page.evaluate(()=>{
    const s=SAILING_GAME.state;
    const axes=SailPhysics.axes(s.theta);
    return {forward:s.vx*axes.fx+s.vy*axes.fy,ground:s.ground.contact,capsized:s.capsized,time:s.time};
  });
  expect(sailing).toMatchObject({ground:false,capsized:false});
  expect(sailing.time).toBeGreaterThan(7.5);
  expect(sailing.forward).toBeGreaterThan(.5);
  await page.keyboard.down('ArrowRight');
  await page.clock.runFor(370);
  const rudder=await page.evaluate(()=>SAILING_GAME.state.rudder);
  await page.keyboard.up('ArrowRight');
  expect(rudder).toBeGreaterThan(.1);
});

test('all five boats start underway in deep water with manual steering and trim',async({page})=>{
  await page.clock.install();
  await page.goto(process.env.TACK_URL||pathToFileURL(path.resolve('index.html')).href);
  await (await introOption(page,'#introBoat')).selectOption('yacht');
  await (await introOption(page,'#introDifficulty')).selectOption('hard');
  await page.clock.pauseAt(await page.evaluate(()=>Date.now()+100));
  await page.click('#startButton');

  const read=()=>page.evaluate(()=>{
    const {state,env,paused}=SAILING_GAME,P=SailPhysics,model=SailingBoats.get(state),axes=P.axes(state.theta);
    return {boat:state.boatId,depth:-SailingWorld.heightAt(state.x,state.y),
      ground:state.ground?.contact??SailingWorld.contact(state,model,env).contact,
      speed:Math.hypot(state.vx,state.vy),forward:state.vx*axes.fx+state.vy*axes.fy,
      sheet:state.sheet,boom:state.boom,awa:state.wind.awa,drive:state.sail.drive,
      rudder:state.rudder,capsized:state.capsized,paused};
  });

  for(const id of ['yacht','dinghy','laser','ac75','ac72']){
    if(id!=='yacht'){
      await page.click('#boatMenuButton');
      await page.locator('[data-boat="'+id+'"]').click();
    }
    const start=await read();
    expect(start).toMatchObject({boat:id,ground:false,capsized:false,paused:false});
    expect(start.depth).toBeGreaterThan(15);
    expect(start.forward).toBeGreaterThan(.9);
    expect(start.boom*start.awa).toBeLessThan(0);
    expect(start.drive).toBeGreaterThan(0);
    await page.clock.runFor(2000);
    const settled=await read();
    expect(settled).toMatchObject({ground:false,capsized:false,sheet:start.sheet});
    expect(settled.forward).toBeGreaterThan(start.forward);

    await page.keyboard.down('ArrowRight');
    await page.keyboard.down('ArrowUp');
    await page.clock.runFor(350);
    await page.keyboard.up('ArrowRight');
    await page.keyboard.up('ArrowUp');
    const steered=await read();
    expect(steered.rudder).toBeGreaterThan(.01);
    expect(steered.sheet).toBeGreaterThan(settled.sheet);
  }
});

test('solo race trim builds forward drive from rest during the countdown',async({page})=>{
  await page.clock.install();
  await page.goto(process.env.TACK_URL||pathToFileURL(path.resolve('index.html')).href);
  await (await introOption(page,'#introBoat')).selectOption('yacht');
  await page.clock.pauseAt(await page.evaluate(()=>Date.now()+100));
  await page.click('#introCourse');
  const read=()=>page.evaluate(()=>{
    const {state,course}=SAILING_GAME;
    const {fx,fy}=SailPhysics.axes(state.theta);
    const {normal,centre}=course.model.startLine;
    return {boat:state.boatId,drive:state.sail.drive,forward:state.vx*fx+state.vy*fy,ground:state.ground?.contact,
      countdown:course.countdown,early:course.ocs,lineDistance:(state.x-centre.x)*normal.x+(state.y-centre.y)*normal.y};
  });
  for(const boat of ['yacht','ac75','ac72','laser']){
    if(boat!=='yacht'){
      await page.click('#boatMenuButton');
      await page.locator('[data-boat="'+boat+'"]').click();
    }
    const start=await read();
    expect(start.boat).toBe(boat);
    expect(start.forward).toBeCloseTo(0,8);
    expect(start.drive).toBeGreaterThan(0);
    await page.clock.runFor(2000);
    const moving=await read();
    expect(moving.forward).toBeGreaterThan(.15);
    expect(moving.countdown).toBeLessThan(start.countdown);
    expect(moving.lineDistance).toBeLessThan(0);
    expect(moving.ground).toBe(false);
  }
  await page.clock.runFor(28400);
  const atSignal=await read();
  expect(atSignal.early).toBe(false);
  expect(atSignal.lineDistance).toBeLessThan(0);
});

test('a tap between physics frames gives one input step without sticking',async({page})=>{
  await page.clock.install();
  await page.goto(pathToFileURL(path.resolve('index.html')).href);
  await page.click('#startButton');
  await page.clock.pauseAt(await page.evaluate(()=>Date.now()+85));
  const read=()=>page.evaluate(()=>{const s=SAILING_GAME.state;return {sheet:s.sheet,time:s.time,helm:s.rudder};});
  const before=await read();
  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('ArrowUp');
  expect(await read()).toEqual(before);
  const samples=[];
  for(let i=0;i<5;i++){
    await page.clock.runFor(16);
    samples.push(await read());
  }
  expect(Math.max(...samples.map(s=>s.helm))).toBeGreaterThan(.01);
  expect(samples.at(-1).helm).toBe(0);
  expect(samples.at(-1).sheet-before.sheet).toBeCloseTo(.5/60,6);
  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('Space');
  await page.clock.runFor(120);
  await page.keyboard.press('Space');
  await page.clock.runFor(100);
  expect((await read()).helm).toBe(0);
});

test('focus loss clears held controls and discards accumulated time',async({page})=>{
  await page.clock.install();
  await page.goto(pathToFileURL(path.resolve('index.html')).href);
  await page.click('#startButton');
  await page.clock.runFor(2500);
  await page.keyboard.down('ArrowRight');
  await page.clock.runFor(350);
  const read=()=>page.evaluate(()=>({pause:SAILING_GAME.paused,time:SAILING_GAME.state.time,input:SAILING_GAME.state.steerIntent}));
  const sailing=await read();
  expect(sailing.input).toBe(1);
  // Chromium in Playwright keeps its automation tabs focused.
  await page.evaluate(()=>window.dispatchEvent(new FocusEvent('blur')));
  await page.clock.runFor(1200);
  expect(await read()).toMatchObject({pause:true,time:sailing.time});
  await page.evaluate(()=>window.dispatchEvent(new FocusEvent('focus')));
  await page.clock.runFor(300);
  const resumed=await read();
  expect(resumed).toMatchObject({pause:false,input:0});
  expect(resumed.time-sailing.time).toBeGreaterThan(.20);
  expect(resumed.time-sailing.time).toBeLessThan(.4);
  await page.keyboard.up('ArrowRight');
});

test('steering keys resume after using the chart selector and trim slider',async({page})=>{
  await page.goto(pathToFileURL(path.resolve('index.html')).href);
  await page.click('#startButton');
  await page.locator('#courseCard').hover();
  const view=page.locator('#mapView');
  await view.focus();
  await view.selectOption('area');
  await page.mouse.move(10,220);
  await expect(page.locator('#sea')).toBeFocused();
  await page.keyboard.down('ArrowRight');
  await page.waitForFunction(()=>SAILING_GAME.state.steerIntent===1&&SAILING_GAME.state.rudder>.05);
  await page.keyboard.up('ArrowRight');
  const slider=await page.locator('#sheetControl').boundingBox();
  await page.mouse.click(slider.x+slider.width*.55,slider.y+slider.height/2);
  await expect(page.locator('#sea')).toBeFocused();
  await page.keyboard.down('ArrowLeft');
  await page.waitForFunction(()=>SAILING_GAME.state.steerIntent===-1&&SAILING_GAME.state.rudder<-.05);
  await page.keyboard.up('ArrowLeft');
});
test('the sailing toolbar keeps the helm active while the sheet or reef control has focus',async({page})=>{
  await page.clock.install();
  await page.goto(process.env.TACK_URL||pathToFileURL(path.resolve('index.html')).href);
  await page.selectOption('#introDifficulty','hard');
  await page.click('#startButton');
  await page.clock.pauseAt(await page.evaluate(()=>Date.now()+150));
  const initialHeading=await page.evaluate(()=>{
    const {state,env}=SAILING_GAME,P=SailPhysics,theta=54*P.DEG;
    Object.assign(env,{speed:8.6,direction:90,gusts:0,waveHeight:0,chop:0,shelter:false});
    Object.assign(state,P.createState({boatId:'laser',x:30,y:-1500,theta,
      vx:2.315*Math.cos(theta),vy:2.315*Math.sin(theta),sheet:P.sheetFromTrim(.408,'laser'),
      crewPose:1,crewPoseBlend:1,crewSide:1,crewSideBlend:1},env),{windClimate:{speed:8.6,direction:90,gusts:0}});
    document.getElementById('pose1').click();
    const sheet=document.getElementById('sheetControl');
    sheet.value='40.8';
    sheet.dispatchEvent(new Event('input'));
    return theta;
  });
  const read=()=>page.evaluate(()=>{
    const {state}=SAILING_GAME;
    return {heading:state.theta,helm:state.steerIntent,rudder:state.rudder,sheet:state.sheet,
      reef:document.getElementById('reefSetting').value};
  });
  await page.locator('#sheetControl').focus();
  await page.keyboard.down('ArrowLeft');
  await page.clock.runFor(550);
  const port=await read();
  expect(port.helm).toBe(-1);
  expect(port.rudder).toBeLessThan(-.2);
  expect(port.heading-initialHeading).toBeGreaterThan(.04);

  await page.keyboard.down('ArrowDown');
  await page.clock.runFor(260);
  await page.keyboard.up('ArrowDown');
  const eased=await read();
  expect(eased.helm).toBe(-1);
  expect(eased.sheet).toBeLessThan(port.sheet-.04);

  await page.locator('#reefSetting').focus();
  await page.clock.runFor(300);
  expect((await read()).helm).toBe(-1);
  await page.keyboard.up('ArrowLeft');
  await page.keyboard.down('ArrowRight');
  await page.clock.runFor(900);
  const starboard=await read();
  expect(starboard).toMatchObject({helm:1,reef:'0'});
  expect(starboard.rudder).toBeGreaterThan(.2);
  await page.keyboard.up('ArrowRight');
  await page.clock.runFor(300);
  expect((await read()).helm).toBe(0);
});

test('the on-screen rudder turns the Laser and releases even outside the button',async({page})=>{
  await page.setViewportSize({width:1440,height:900});
  await page.clock.install();
  await page.goto(process.env.TACK_URL||pathToFileURL(path.resolve('index.html')).href);
  await page.selectOption('#introDifficulty','hard');
  await page.click('#startButton');
  await page.clock.pauseAt(await page.evaluate(()=>Date.now()+120));
  await page.evaluate(()=>{
    const {state,env}=SAILING_GAME,P=SailPhysics,theta=-28*P.DEG,speed=5/1.94384;
    Object.assign(env,{speed:7.8,direction:90,gusts:0,waveHeight:.35,chop:.4,shelter:false});
    Object.assign(state,TackSimulation.createBoat('laser',{x:0,y:-1500,theta,
      vx:speed*Math.cos(theta),vy:speed*Math.sin(theta),sheet:P.sheetFromTrim(.939,'laser'),
      crewPose:3,crewPoseBlend:3,crewSide:-1,crewSideBlend:-1},env),{windClimate:{speed:7.8,direction:90,gusts:0}});
    document.getElementById('pose3').click();
    const sheet=document.getElementById('sheetControl');
    sheet.value='93.9';sheet.dispatchEvent(new Event('input'));
  });
  const read=()=>page.evaluate(()=>{
    const {state}=SAILING_GAME;
    return {input:state.steerIntent,rudder:state.rudder,heading:state.theta,
      rudderMoment:state.forces.yawRudder,ground:state.ground?.contact};
  });
  await page.getByRole('button',{name:'Drej mod styrbord'}).click();
  const tapSteps=[];
  for(let i=0;i<4;i++){
    await page.clock.runFor(17);
    tapSteps.push(await read());
  }
  expect(tapSteps.some(s=>s.input===1&&s.rudder>0)).toBe(true);
  expect(tapSteps.at(-1).input).toBe(0);

  const left=page.getByRole('button',{name:'Drej mod bagbord'}),box=await left.boundingBox();
  const start=await read();
  await page.mouse.move(box.x+box.width/2,box.y+box.height/2);
  await page.mouse.down();
  await page.mouse.move(20,80);
  await page.clock.runFor(680);
  const held=await read();
  expect(held).toMatchObject({input:-1,ground:false});
  expect(held.rudder).toBeLessThan(-.22);
  expect(held.rudderMoment).toBeGreaterThan(0);
  expect(held.heading-start.heading).toBeGreaterThan(.08);
  await page.mouse.up();
  await page.clock.runFor(370);
  expect(await read()).toMatchObject({input:0,rudder:0});
});

test('dragging the map during a race keeps its anchor and view',async({page})=>{
  const errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  await page.goto(pathToFileURL(path.resolve('index.html')).href);
  await page.click('#introCourse');
  await page.waitForFunction(()=>SAILING_GAME.state.time>.1);
  const chart=page.locator('#courseCard');
  const before=await chart.boundingBox();
  const controls=chart.locator('.map-controls');
  await expect(controls).toBeHidden();
  await expect(chart.locator('#raceTime')).toBeVisible();
  expect(await chart.locator('#map').boundingBox()).toEqual(before);
  const plot=await page.evaluate(()=>SAILING_GAME.map._plot());
  expect(plot).toEqual({left:0,top:0,right:before.width,bottom:before.height});
  await chart.hover();
  await expect(controls).toBeVisible();
  expect(await chart.locator('#map').boundingBox()).toEqual(before);
  await page.mouse.move(20,250);
  await expect(controls).toBeHidden();
  await chart.locator('#map').focus();
  await page.keyboard.press('Tab');
  await expect(controls).toBeVisible();
  await page.locator('#sea').focus();
  await expect(controls).toBeHidden();
  const view=await page.evaluate(()=>({time:SAILING_GAME.state.time,scale:SAILING_GAME.map.view.scale,width:SAILING_GAME.map.width}));
  await dragMap(page,290,135);
  await expect.poll(async()=>(await chart.boundingBox()).width).toBeCloseTo(before.width+290,0);
  const expanded=await chart.boundingBox();
  expect(expanded.height).toBeGreaterThan(before.height);
  expect(expanded.x+expanded.width).toBeCloseTo(before.x+before.width,0);
  expect(expanded.y).toBeCloseTo(before.y,0);
  await expect.poll(()=>page.evaluate(()=>SAILING_GAME.map.width)).toBeGreaterThan(view.width+250);
  await dragMap(page,-83,-39);
  await expect.poll(async()=>(await chart.boundingBox()).width).toBeCloseTo(expanded.width-83,0);
  await expect.poll(async()=>(await chart.boundingBox()).height).toBeCloseTo(expanded.height-39,0);
  const during=await page.evaluate(()=>({time:SAILING_GAME.state.time,scale:SAILING_GAME.map.view.scale,paused:SAILING_GAME.paused}));
  expect(during.time).toBeGreaterThan(view.time);
  expect(during.paused).toBe(false);
  expect(during.scale).toBeCloseTo(view.scale,4);
  const map=await page.locator('#map').boundingBox();
  const x=map.x+map.width/2,y=map.y+map.height/2;
  await page.mouse.move(x,y);
  await page.mouse.down();
  await page.mouse.move(x+35,y+10,{steps:4});
  await page.mouse.up();
  await expect.poll(()=>page.evaluate(()=>SAILING_GAME.map.mode)).toBe('manual');
  expect(errors).toEqual([]);
});
test('typing clears a held helm command and leaves digits in the input',async({page})=>{await page.goto(pathToFileURL(path.resolve('index.html')).href);await page.waitForFunction(()=>!!window.SAILING_GAME);await page.click('#startButton');await page.keyboard.down('ArrowLeft');await page.waitForTimeout(300);expect(await page.evaluate(()=>SAILING_GAME.state.steerIntent)).toBe(-1);await page.evaluate(()=>{let i=document.createElement('input');i.id='testName';i.type='text';document.body.appendChild(i);i.focus()});await page.keyboard.type('123');await page.waitForTimeout(300);expect(await page.locator('#testName').inputValue()).toBe('123');expect(await page.evaluate(()=>SAILING_GAME.state.steerIntent)).toBe(0);await page.keyboard.up('ArrowLeft')});
test('slack sheet is taken in faster on all models without invalidating physics self tests',async({page})=>{await page.goto(pathToFileURL(path.resolve('index.html')).href);await page.waitForFunction(()=>!!window.SAILING_GAME);const result=await page.evaluate(()=>{const out=[];for(const boatId of ['laser','dinghy','yacht','ac75','ac72']){const env={...SAILING_GAME.env,boatId},slow=SailPhysics.createState({},env),fast=SailPhysics.createState({},env);for(const s of [slow,fast]){s.sheet=0;s.boom=.15;s.boomRate=0}for(let i=0;i<15;i++){SailPhysics.step(slow,{trim:1,crewPose:2},env,1/60);SailPhysics.step(fast,{trim:1,trimFast:true,crewPose:2},env,1/60)}out.push({boatId,slow:slow.sheet,fast:fast.sheet,finite:Number.isFinite(fast.heel)&&Number.isFinite(fast.boom)});}return {out,failed:SAILING_GAME.selfTests().filter(x=>!x.pass)};});expect(result.failed).toEqual([]);for(const r of result.out){expect(r.fast).toBeGreaterThan(r.slow);expect(r.finite).toBe(true)}});
test('up arrow takes in a loose sheet in the running browser',async({page})=>{await page.goto(pathToFileURL(path.resolve('index.html')).href);await page.waitForFunction(()=>!!window.SAILING_GAME);await page.click('#startButton');await page.evaluate(()=>{SAILING_GAME.state.sheet=0;SAILING_GAME.state.boom=.15;SAILING_GAME.state.boomRate=0});await page.keyboard.down('ArrowUp');await page.waitForTimeout(500);await page.keyboard.up('ArrowUp');const s=await page.evaluate(()=>({sheet:SAILING_GAME.state.sheet,time:SAILING_GAME.state.time}));expect(s.sheet).toBeGreaterThan(.2)});
test('five pictured cards select their actual boat',async({page})=>{await page.goto(pathToFileURL(path.resolve('index.html')).href);await page.waitForFunction(()=>!!window.SAILING_GAME);await page.click('#startButton');for(const boat of ['laser','dinghy','yacht','ac75','ac72']){await page.click('#boatMenuButton');const card=page.locator(`[data-boat="${boat}"]`);expect(await card.locator('img').evaluate(i=>i.complete&&i.naturalWidth>0)).toBe(true);await card.click();await expect(page.locator('#boatPicker')).toBeHidden();expect(await page.evaluate(()=>SAILING_GAME.state.boatId)).toBe(boat);await page.click('#boatMenuButton');await expect(card).toHaveAttribute('aria-pressed','true');await page.keyboard.press('Escape')} });
test('boat and crew visuals follow the current simulated pose on every boat',async({page})=>{
  const errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  await page.goto(pathToFileURL(path.resolve('index.html')).href);
  await page.click('#startButton');
  for(const boat of ['laser','dinghy','yacht','ac75','ac72']){
    await page.click('#boatMenuButton');
    await page.click(`[data-boat="${boat}"]`);
    await expect(page.locator('#boatPicker')).toBeHidden();
    expect(await page.evaluate(()=>SAILING_GAME.paused)).toBe(false);
    await page.keyboard.press('3');
    await page.keyboard.down('ArrowLeft');
    await page.waitForFunction(id=>SAILING_GAME.scene.boatId===id&&SAILING_GAME.state.crewPoseBlend>2.25,boat);
    await page.keyboard.up('ArrowLeft');
    const result=await page.evaluate(()=>{
      const {scene,state}=SAILING_GAME;
      const person=scene.foilingCrew?.[0]?.person||scene.person;
      const leg=person.rig.chain[0];
      const ankle=leg.end.getWorldPosition(new THREE.Vector3());
      const boot=person.feet[0].getWorldPosition(new THREE.Vector3());
      return {pose:state.crewPose,knee:leg.middle.position.length(),ankleGap:ankle.distanceTo(boot),
        sail:!!scene.sailMesh,heel:Number.isFinite(scene.hull.rotation.x)};
    });
    expect(result.pose).toBe(3);
    expect(result.knee).toBeGreaterThan(.2);
    expect(result.ankleGap).toBeLessThan(.06);
    expect(result.sail&&result.heel).toBe(true);
  }
  expect(errors).toEqual([]);
});
test('solo race countdown stops during pause and resumes',async({page})=>{
 await page.clock.install();
 await page.goto(pathToFileURL(path.resolve('index.html')).href);
 await page.waitForFunction(()=>!!window.SAILING_GAME);
 await page.click('#introCourse');
 await page.clock.pauseAt(await page.evaluate(()=>Date.now()+100));
 await page.keyboard.press('Space');
 const read=()=>page.evaluate(()=>({t:SAILING_GAME.course.countdown,sim:SAILING_GAME.state.time}));
 const before=await read();
 await page.clock.runFor(1000);
 expect(await read()).toEqual(before);
 await page.keyboard.press('Space');
 await page.clock.runFor(400);
 const after=await read();
 expect(after.t).toBeLessThan(before.t-.2);
 expect(after.t).toBeGreaterThan(before.t-.8);
});
test('held keyboard trim spans the full interval in about two seconds for all boats',async({page})=>{await page.goto(pathToFileURL(path.resolve('index.html')).href);await page.waitForFunction(()=>!!window.SAILING_GAME);const results=await page.evaluate(()=>['laser','dinghy','yacht','ac75','ac72'].map(boatId=>{let env={...SAILING_GAME.env,boatId};let s=SailPhysics.createState({},env),out=[];for(const start of [0,1]){s.sheet=start;for(let i=0;i<120;i++)SailPhysics.step(s,{trim:start?-1:1,trimFast:true,crewPose:2},env,1/60);out.push(s.sheet)}return {boatId,out}}));for(const r of results){expect(r.out[0]).toBeGreaterThan(.98);expect(r.out[1]).toBeLessThan(.02)}});
test('all five boats accept the manual side commands on hard in calm air',async({page})=>{
 await page.goto(pathToFileURL(path.resolve('index.html')).href);
 await (await introOption(page,'#introWeatherEdit')).click();
 await page.locator('#windSpeed').fill('0');
 await page.keyboard.press('Escape');
 await page.click('#startButton');
 for(const id of ['laser','dinghy','yacht','ac75','ac72']){
  if(id!=='laser'){
   await page.keyboard.press('KeyB');
   await page.locator('[data-boat="'+id+'"]').click();
  }
  await page.keyboard.press('3');
  for(const [key,side] of [['KeyE',1],['KeyQ',-1]]){
   await page.keyboard.press(key);
   await page.waitForFunction(({id,side})=>{
    const s=SAILING_GAME.state;
    return s.boatId===id&&s.crewDifficulty==='hard'&&s.crewSide===side&&s.crewPose===3;
   },{id,side});
  }
 }
});
test('the mobile chart resizes by touch and keeps zoom and navigation',async({browser})=>{
  const context=await browser.newContext({viewport:{width:390,height:844},hasTouch:true});
  try{
    const page=await context.newPage();
    await page.goto(pathToFileURL(path.resolve('index.html')).href);
    await page.tap('#startButton');
    const chart=page.locator('#courseCard');
    const before=await chart.boundingBox();
    const controls=chart.locator('.map-controls');
    await expect(controls).toBeHidden();
    await chart.locator('#map').tap();
    await expect(controls).toBeVisible();
    expect(await chart.locator('#map').boundingBox()).toEqual(before);
    const handle=await page.locator('#mapResize').boundingBox();
    const x=Math.round(handle.x+handle.width/2),y=Math.round(handle.y+handle.height/2);
    const input=await context.newCDPSession(page);
    await input.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});
    await input.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x-36,y:y+36}]});
    await expect.poll(async()=>(await chart.boundingBox()).width).toBeCloseTo(before.width+36,0);
    await input.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x-74,y:y+68}]});
    await input.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
    await expect.poll(async()=>(await chart.boundingBox()).width).toBeCloseTo(before.width+74,0);
    const resized=await chart.boundingBox();
    expect(resized.x+resized.width).toBeCloseTo(before.x+before.width,0);
    expect(resized.height).toBeCloseTo(before.height+68,0);
    const scale=await page.evaluate(()=>SAILING_GAME.map.goal.scale);
    await page.tap('#mapZoomIn');
    expect(await page.evaluate(()=>SAILING_GAME.map.goal.scale)).toBeGreaterThan(scale);
    await page.touchscreen.tap(122,380);
    await expect(controls).toBeHidden();
    for(const id of ['cameraButton','boatMenuButton','settingsButton','raceButton','preferencesButton']){
      await expect(page.locator('#'+id)).toBeVisible();
    }
    await page.reload();
    await page.tap('#startButton');
    await expect.poll(async()=>(await chart.boundingBox()).width).toBeCloseTo(resized.width,0);
  }finally{await context.close();}
});
